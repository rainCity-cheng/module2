package com.lagou.part2;

/**
 * 五子棋测试类
 */
public class FiveChessTest {

    public static void main(String[] args) {

        FiveChess fc = new FiveChess();
        fc.initBoard();
        fc.printBoard();
        boolean win = false; // 判断输赢
        String color = "●"; //棋子
        String chesscolor; // 黑棋和白棋
        for(;;) {
            //调用下棋的方法并接收返回的boolean值
            win = fc.play(color);
            if("●".equals(color)){
                chesscolor = "黑棋";
            }else{
                chesscolor = "白棋";
            }
            // 判断胜负 true表示胜利，并结束游戏
            if(win){
                System.out.println("恭喜" + chesscolor + "获胜！！游戏结束！！！");
                break;
            }
            if("●".equals(color)){
                color = "○";
            }else {
                color = "●";
            }
        }
    }
}
