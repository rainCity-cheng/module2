package com.lagou.part2;

/**
 * 通话服务接口
 */
public interface CallMenuInterface {

    //自定义参数为通话时间和卡类型的成员方法
    public void call(int cardTime, Card type);
}
