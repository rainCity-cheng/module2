package com.lagou.part2;

/**
 *  用户消费信息类
 */
public class UserConsume {

    //统计通话时长的成员方法
    public void callTime(){
        System.out.println("通话时长");
    }

    //统计上网流量的成员方法
    public void netFlow() {
        System.out.println("上网流量");
    }

    //每月消费余额的成员方法
    public void moothlyBalance(){
        System.out.println("每月消费余额");
    }
}
