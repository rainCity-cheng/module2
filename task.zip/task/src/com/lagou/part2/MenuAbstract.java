package com.lagou.part2;

/**
 * 通话套餐和上网套餐接口
 */
public abstract class MenuAbstract {

    double price; //每月资费

    public MenuAbstract() {
    }

    public MenuAbstract(double price) {
        this.price = price;
    }

    //显示套餐的方法
    public abstract void showMenu();

}
