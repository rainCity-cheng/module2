package com.lagou.part2;

import java.util.Scanner;

/**
 * 自定义类型实现棋盘的绘制
 */
public class FiveChess {

    // 声明类型为String的二维数组
    private static int SIZE = 17;    // 定义棋盘大小
    private String[][] arr;

    //给棋盘赋值
    public void initBoard() {
        arr = new String[SIZE][SIZE];
        int a = 0; // 表示棋盘的横坐标
        int b = 0; // 表示棋盘的纵坐标

        //使用双重for循环赋值
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (0 == i && 0 == j){
                    arr[i][j] = " ";
                } else if (0 == i && j > 0) {
                    arr[i][j] = Integer.toHexString(a);
                    a++;
                } else if (0 == j && i > 0) {
                    arr[i][j] = Integer.toHexString(b);
                    b++;
                }else {
                    arr[i][j] = "+";
                }
            }
        }
    }


    /**
     *  打印棋盘的方法
     */
    public void printBoard() {
        //打印棋盘
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < SIZE; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
    }

    //下棋的方法
    public boolean play(String color){
        Scanner sc = new Scanner(System.in);
        String chesscolor;
        if("●".equals(color)){
            chesscolor = "黑棋";
        }else{
            chesscolor = "白棋";
        }
        System.out.println("请输入" + chesscolor + "的位置(格式为x y)：");
        int x = Integer.parseInt(sc.next(), 16);
        int y = Integer.parseInt(sc.next(), 16);
        y++;
        x++;
        // 数组越界判断
        if(!(x > 0 && x < SIZE && y > 0 && y < SIZE)){
            System.out.println("输入的是错误的坐标！！");
            play(color);
        } else if ("●".equals(arr[x][y]) || "○".equals(arr[x][y])) { // 位置是否重复判断
            System.out.println("位置重复，请重新输入！！");
            play(color);
        } else {
            this.arr[x][y] = color;
            //打印走棋之后的棋盘
            printBoard();
            // 接收判断棋子连续的数目
            int cnt1 = rowJudge(x, y); // 横向
            int cnt2 = colJudge(x, y); // 纵向
            int cnt3 = leftJudge(x, y); // 正斜
            int cnt4 = rightJudge(x, y); // 反斜
            // 判断连续棋子是否达到5个 是则返回true
            if(cnt1 == 5 || cnt2 == 5 || cnt3 == 5 || cnt4 == 5){
                return true;
            }
        }
        return false;
    }

    //判断横向是否够连续的五个棋子
    public int rowJudge(int x, int y) {
        int cnt = 1; //记录连续的棋子数
        for (int i = x+1; i < SIZE; i++) {
            if(arr[i][y] == arr[x][y] ){
                cnt++;
            }else {
                break;
            }
        }
        for (int i = x-1; i > 0; i--) {
            if(arr[i][y] == arr[x][y] ){
                cnt++;
            }else {
                break;
            }
        }
        return cnt;
    }
    //判断纵向是否够连续的五个棋子
    public int colJudge(int x, int y) {
        int cnt = 1; //记录连续的棋子数
        for (int i = y+1; i < SIZE; i++) {
            if(arr[x][i] == arr[x][y] ){
                cnt++;
            }else {
                break;
            }
        }
        for (int i = y-1; i > 0; i--) {
            if(arr[x][i] == arr[x][y] ){
                cnt++;
            }else {
                break;
            }
        }
        return cnt;
    }


    //判断正斜方向是否够连续的五个棋子
    public int leftJudge(int x, int y) {
        int cnt = 1; //记录连续的棋子数
        int s = y;
        for (int i = x+1; i < SIZE; i++) {
            if((s+1) < SIZE) {
                s++;
                if (arr[i][s] == arr[x][y]) {
                    cnt++;
                } else {
                    break;
                }
            }else{
                break;
            }
        }
        s = y;
        for (int i = x-1; i < SIZE; i--) {
            if((s-1) > 0) {
                s--;
                if (arr[i][s] == arr[x][y]) {
                    cnt++;
                } else {
                    break;
                }
            } else {
                break;
            }
        }
        return cnt;
    }

    //判断反斜方向是否够连续的五个棋子
    public int rightJudge(int x, int y) {
        int cnt = 1; //记录连续的棋子数
        int s = y;
        for (int i = x+1; i < SIZE; i++) {

            if ((s-1) > 0) {
                s--;
                if (arr[i][s] == arr[x][y]) {
                    cnt++;
                } else {
                    break;
                }
            } else {
                break;
            }
        }
        s = y;
        for (int i = x-1; i < SIZE; i--) {
            if((s+1) < SIZE) {
                s++;
                if (arr[i][s] == arr[x][y]) {
                    cnt++;
                } else {
                    break;
                }
            } else {
                break;
            }
        }
        return cnt;
    }
}
