package com.lagou.part2;

/**
 * 手机卡类
 */
public class PhoneCard {
    private String cardType; // 卡类型
    private int cardNum; // 卡号
    private String userName; // 用户名
    private String password; // 密码
    private double balance; // 余额
    private int callTime;    // 通话时长
    private double flow;    // 流量

    public PhoneCard() {
    }

    public PhoneCard(String cardType, int cardNum, String userName, String password, double balance, int callTime, double flow) {
        setCardType(cardType);
        setCardNum(cardNum);
        setUserName(userName);
        setPassword(password);
        setBalance(balance);
        setCallTime(callTime);
        setFlow(flow);
    }



    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public int getCardNum() {
        return cardNum;
    }

    public void setCardNum(int cardNum) {
        this.cardNum = cardNum;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public int getCallTime() {
        return callTime;
    }

    public void setCallTime(int callTime) {
        this.callTime = callTime;
    }

    public double getFlow() {
        return flow;
    }

    public void setFlow(double flow) {
        this.flow = flow;
    }

    // 自定义成员方法显示卡号 用户名 余额
    public void show() {
        System.out.println("卡号为" + getCardNum() + "，用户名为" + getUserName() + "的余额是：" + getBalance() + "元。");
    }
}
