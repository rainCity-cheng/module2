package com.lagou.part2;

/**
 * 卡类型接口
 */
public interface CardInterface {
    public abstract void show();
}
