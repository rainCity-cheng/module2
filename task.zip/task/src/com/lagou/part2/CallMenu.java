package com.lagou.part2;

/**
 * 通话套餐类
 */
public class CallMenu extends MenuAbstract implements CallMenuInterface{
    private int cardTime; // 通话时长
    private int shortMessage; // 短信条数
   // private double callPrice; // 每月资费

    public CallMenu() {
    }

    public CallMenu(double price, int cardTime, int shortMessage) {
        super(price);
        this.cardTime = cardTime;
        this.shortMessage = shortMessage;
    }

    public int getCardTime() {
        return cardTime;
    }

    public void setCardTime(int cardTime) {
        this.cardTime = cardTime;
    }

    public int getShortMessage() {
        return shortMessage;
    }

    public void setShortMessage(int shortMessage) {
        this.shortMessage = shortMessage;
    }

   /* public double getCallPrice() {
        return callPrice;
    }

    public void setCallPrice(double callPrice) {
        this.callPrice = callPrice;
    }*/

    /*// 自定义成员方法显示所有套餐信息
    public void showCall() {
        System.out.println("本月通话时长为：" + getCardTime() + "分钟，共发送短信：" + getShortMessage() + "条, 本月通话套餐的费用为：" + getCallPrice() +"元。");
    }*/

    @Override
    public void showMenu() {
        System.out.println("本月通话时长为：" + getCardTime() + "分钟，共发送短信：" + getShortMessage() + "条, 本月通话套餐的费用为：" + super.price +"元。");
    }

    @Override
    public void call(int cardTime, Card type) {
        System.out.println("通话时长为：" + cardTime + "分钟，卡的类型为：" + type);
    }
}
