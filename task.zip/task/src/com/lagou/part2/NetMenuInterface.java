package com.lagou.part2;

/**
 * 上网信息接口
 */
public interface NetMenuInterface {
    // 上网信息方法
    public void showNet(double flow, Card type);
}
