package com.lagou.part2;

import org.w3c.dom.ls.LSOutput;

/**
 * 卡类型枚举
 */
public enum Card implements CardInterface{

    BIG_CARD("大卡"){
        @Override
        public void show() {
            System.out.println("大卡！");
        }
    }, SMALL_CARD("小卡"){
        @Override
        public void show() {
            System.out.println("小卡！");
        }
    }, MICRO_CARD("微型卡"){
        @Override
        public void show() {
            System.out.println("微型卡！");
        }
    };

    // 用于描述卡类型的成员变量
    private final String type;

    // 私有化构造方法
    private Card(String type){
        this.type = type;
    }
}
