package com.lagou.part2;

import java.util.concurrent.Callable;

/**
 *
 */
public class CardTest {

    public static void main(String[] args) {

        //手机卡类
        PhoneCard pc = new PhoneCard("大卡",100011, "admin", "123456", 20.0, 50, 100.2);
        pc.show();
        //套餐信息类的引用指向通话套餐类的对象
        MenuAbstract cardMenu = new CallMenu(20.2, 500, 20);
        cardMenu.showMenu();
        //套餐信息类的引用指向上网套餐类的对象
        MenuAbstract netMenu = new InternetMenu(30.2, 500.2);
        netMenu.showMenu();

        //父类引用调用子类方法需要强转
        ((InternetMenu) netMenu).showNet(pc.getFlow(), Card.BIG_CARD);
        ((CallMenu)cardMenu).call(pc.getCallTime(),Card.MICRO_CARD);

        //获取卡类型中的所有枚举对象并打印方法
        Card[] arr = Card.values();
        for (int i = 0; i < arr.length; i++) {
            arr[i].show();
        }
    }
}
