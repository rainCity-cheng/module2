package com.lagou.part2;

/**
 * 上网套餐类
 */
public class InternetMenu extends MenuAbstract implements NetMenuInterface{
    private double netFlow; // 上网流量
    //private double netPrice; // 每月资费

    public InternetMenu() {
    }

    public InternetMenu(double price, double netFlow) {
        super(price);
        this.netFlow = netFlow;
    }

    public double getNetFlow() {
        return netFlow;
    }

    public void setNetFlow(double netFlow) {
        this.netFlow = netFlow;
    }

   /* public double getNetPrice() {
        return netPrice;
    }

    public void setNetPrice(double netPrice) {
        this.netPrice = netPrice;
    }*/

    /*// 自定义成员方法显示套餐信息
    public void showNet(){
        System.out.println("本月使用的流量为：" + getNetFlow() + "Mb，共消费：" + getNetPrice() + "元。");
    }
*/
    @Override
    public void showMenu() {
        System.out.println("本月使用的流量为：" + getNetFlow() + "Mb，共消费：" + super.price + "元。");
    }

    @Override
    public void showNet(double flow, Card type) {
        System.out.println("卡类型为：" + type + "，上网流量：" + flow + "Mb。");
    }
}
